#ifndef WINDOWS_H
#define WINDOWS_H

char *strsep(char **stringp, const char *delim);

#endif